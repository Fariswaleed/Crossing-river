/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import java.awt.image.BufferedImage;

/**
 *
 * @author Muhammmad Akram
 */
public class Plant implements ICrosser{
    private double weight=5;
    private int eatingRank=1;
    private int mode;

    public Plant(int mode) {
        this.mode = mode;
    }

    public int getMode() {
        return mode;
    }

    protected int position;
    
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
    
    @Override
    public boolean canSail() {
       return false;
    }

    @Override
    public double getWeight() {
        return this.weight;
    }

    @Override
    public int getEatingRank() {
          return this.eatingRank;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ICrosser makeCopy() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setLabelToBeShown(String label) {
        this.weight=Double.parseDouble(label);
        
        }

    @Override
    public String getLabelToBeShown() {
        String kg=new String(" kg");
    return String.valueOf(this.weight)+kg;
    }
}
