/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import com.sun.javafx.geom.Curve;
import com.sun.javafx.geom.RectBounds;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.PathTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.NodeOrientation;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Path;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.QuadCurve;


/**
 * FXML Controller class
 *
 * @author Muhammmad Akram
 */
public class LeveloneSceneController extends CharacterPosition implements Initializable,ICrossingStrategy  {

    /**
     * Initializes the controller class.
     */
    Lion lion1=new Lion(5);
    Fox fox1=new Fox(0);
    Sheep sheep1= new Sheep(1);
    Goat goat1= new Goat(6);
    Farmer farmer1= new Farmer(3);
    Plant plant1=new Plant(2);
    List<ICrosser> rightBankCrossers = new ArrayList<ICrosser>();
    List<ICrosser> leftBankCrossers =new ArrayList<ICrosser>();
    List<ICrosser> boatRiders = new ArrayList<ICrosser>();
    int moves=0;
    int boat=5;
    
    @FXML
    private Button raftMotion;
    int x=0;
    int currentPosition=0;
    @FXML
    private ImageView k;
    @FXML
    private ImageView sheep;
    @FXML
    private ImageView farmer;
    @FXML
    private ImageView plant;
    @FXML
    private ImageView fox;
    @FXML
    private ImageView lion;
    @FXML
    private ImageView goat;
    
    
    
//    @FXML
//    private void bagarb(ActionEvent event) throws IOException {
//        path.getElements().add(moveTO);
//        path.getElements().add(arcTo);
//        
//    }
    
    @FXML
    private void reload(ActionEvent event) throws IOException {
        System.out.println("Reload Action");
        
    }
        @FXML
    private void Back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Levels.fxml"));
        
        Scene scene = new Scene(root);
        
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(scene);
        window.show();
        
    }
        @FXML
    private void hint(ActionEvent event) throws IOException {
        System.out.println("hint Action");
        
    }
     @FXML
    private void moveSheepToRaft(MouseEvent event) throws IOException { 
        if (isValidJumpOnBoat()&&!(boatRiders.contains(sheep1))) {
             
             if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(sheep1)){setPositionToCharacterPlace_B(1);
              sheep.setLayoutX(509);
              sheep.setLayoutY(275);
              rightBankCrossers.remove(sheep1);          }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(sheep1)){setPositionToCharacterPlace_B(1);
              sheep.setLayoutX(450);
              sheep.setLayoutY(275);
              rightBankCrossers.remove(sheep1);
             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(sheep1)){
             sheep.setLayoutX(270);
             sheep.setLayoutY(275);
             leftBankCrossers.remove(sheep1);
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(sheep1)){
             sheep.setLayoutX(209);
             sheep.setLayoutY(275);
             leftBankCrossers.remove(sheep1);
             }
             
             
            boatRiders.add((ICrosser) sheep1);
         }
         else if((boatRiders.contains(sheep1)||boatRiders.contains(sheep1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(sheep1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(sheep1);
                }
                }
                removePositionToCharacterPlace_B(1);
                sheep.setLayoutX(746);
                sheep.setLayoutY(242);
                
         }
         else if((boatRiders.contains(sheep1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(sheep1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(sheep1);
                }
                }
                removePositionToCharacterPlace_B(1);
                sheep.setLayoutX(54);
                sheep.setLayoutY(242);        
         }
        if (leftBankCrossers.size()==4)System.out.println("youu Won ;)"); 
    }@FXML
     private void moveFarmerToRaft(MouseEvent event) throws IOException {
        if (isValidJumpOnBoat()&&!(boatRiders.contains(farmer1))) {
             
              if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(farmer1)){setPositionToCharacterPlace_B(3);
              farmer.setLayoutX(509);
              farmer.setLayoutY(275);
              rightBankCrossers.remove(farmer1);          }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(farmer1)){setPositionToCharacterPlace_B(3);
              farmer.setLayoutX(450);
              farmer.setLayoutY(275);
              rightBankCrossers.remove(farmer1);
             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(farmer1)){
             farmer.setLayoutX(270);
             farmer.setLayoutY(275);
             leftBankCrossers.remove(farmer1);
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(farmer1)){
             farmer.setLayoutX(209);
             farmer.setLayoutY(275);
             leftBankCrossers.remove(farmer1);
             }
             
             
            boatRiders.add((ICrosser) farmer1);
         }
         else if((boatRiders.contains(farmer1)||boatRiders.contains(farmer1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(farmer1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(farmer1);
                }
                }
                removePositionToCharacterPlace_B(3);
                farmer.setLayoutX(746);
                farmer.setLayoutY(242);
                
         }
         else if((boatRiders.contains(farmer1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(farmer1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(farmer1);
                }
                }
                removePositionToCharacterPlace_B(3);
                farmer.setLayoutX(54);
                farmer.setLayoutY(242);  }
        if (leftBankCrossers.size()==4)System.out.println("youu Won ;)");
         }
     
        @FXML
        private void moveLionToRaft(MouseEvent event) throws IOException {
        if (isValidJumpOnBoat()&&!(boatRiders.contains(lion1))) {
             
             if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(lion1)){setPositionToCharacterPlace_B(5);
              lion.setLayoutX(509);
              lion.setLayoutY(275);
              rightBankCrossers.remove(lion1);
             
             }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(lion1)){setPositionToCharacterPlace_B(5);
              lion.setLayoutX(450);
              lion.setLayoutY(275);
              rightBankCrossers.remove(lion1);
             
             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(lion1)){
             lion.setLayoutX(270);
             lion.setLayoutY(275);
             leftBankCrossers.remove(lion1);
             
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(lion1)){
             lion.setLayoutX(209);
             lion.setLayoutY(275);
             leftBankCrossers.remove(lion1);
             
             }
             
             
            boatRiders.add((ICrosser) lion1);
         }
         else if((boatRiders.contains(lion1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(lion1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(lion1);
                }
                }
                removePositionToCharacterPlace_B(1);
                 System.out.println(getPlace_B(0)+"<--");
                  lion.setLayoutX(692);
                  lion.setLayoutY(226);
                
         }
         else if((boatRiders.contains(lion1)||boatRiders.contains(lion1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(lion1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(lion1);
                }
                }
                removePositionToCharacterPlace_B(1);
                   lion.setLayoutX(108);
                    lion.setLayoutY(242);      
         }if (leftBankCrossers.size()==4)System.out.println("youu Won ;)");
        }

         
               @FXML
         private void moveGoatToRaft(MouseEvent event) throws IOException {
             if (isValidJumpOnBoat()&&!(boatRiders.contains(lion1))) {
             
              if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(goat1)){setPositionToCharacterPlace_B(6);
              goat.setLayoutX(509);
              goat.setLayoutY(275);
              rightBankCrossers.remove(goat1);
             
              }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(goat1)){setPositionToCharacterPlace_B(6);
              goat.setLayoutX(450);
              goat.setLayoutY(275);
              rightBankCrossers.remove(goat1);

             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(goat1)){
             goat.setLayoutX(270);
             goat.setLayoutY(275);
             leftBankCrossers.remove(goat1);
             
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(goat1)){
             goat.setLayoutX(209);
             goat.setLayoutY(275);
             leftBankCrossers.remove(goat1);
             
             }
             
             
            boatRiders.add((ICrosser) goat1);
         }
         else if((boatRiders.contains(goat1)||boatRiders.contains(goat1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(goat1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(goat1);
                }
                }
                removePositionToCharacterPlace_B(1);
                goat.setLayoutX(746);
                goat.setLayoutY(242);
                
         }
         else if((boatRiders.contains(goat1)||boatRiders.contains(goat1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(goat1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(goat1);
                }
                }
                removePositionToCharacterPlace_B(1);
                    goat.setLayoutX(54);
                    goat.setLayoutY(242);       
         }if (leftBankCrossers.size()==4)System.out.println("youu Won ;)");}
         @FXML
             private void moveplantToRaft(MouseEvent event) throws IOException {
            if (isValidJumpOnBoat()&&!(boatRiders.contains(plant1)||boatRiders.contains(plant1))) {
              if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(plant1)){setPositionToCharacterPlace_B(2);
              plant.setLayoutX(509);
              plant.setLayoutY(275);
              rightBankCrossers.remove(plant1);
             
              }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(plant1)){setPositionToCharacterPlace_B(2);
              plant.setLayoutX(450);
              plant.setLayoutY(275);
              rightBankCrossers.remove(plant1);
             
             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(plant1)){
             plant.setLayoutX(270);
             plant.setLayoutY(275);
             leftBankCrossers.remove(plant1);
             
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(plant1)){
             plant.setLayoutX(209);
             plant.setLayoutY(275);
             leftBankCrossers.remove(plant1);
             
             }
             
             
            boatRiders.add((ICrosser) plant1);
         }
         else if((boatRiders.contains(plant1)||boatRiders.contains(plant1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(plant1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(plant1);
                }
                }
                removePositionToCharacterPlace_B(1);
                 System.out.println(getPlace_B(0)+"<--");
                   plant.setLayoutX(638);
              plant.setLayoutY(214);
                
         }
         else if((boatRiders.contains(plant1)||boatRiders.contains(plant1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(plant1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(plant1);
                }
                }
                removePositionToCharacterPlace_B(1);
                     plant.setLayoutX(162);
                    plant.setLayoutY(242);        
         }if (leftBankCrossers.size()==4)System.out.println("youu Won ;)");}
               
            @FXML   
        private void moveFoxToRaft(MouseEvent event) throws IOException {
        if (isValidJumpOnBoat()&&!(boatRiders.contains(fox1)||boatRiders.contains(fox1))) {
             
        if((getPlace_B(0)==0)&&(boat==5)&&rightBankCrossers.contains(fox1)){setPositionToCharacterPlace_B(0);
              fox.setLayoutX(509);
              fox.setLayoutY(275);
              rightBankCrossers.remove(fox1);          }
             else if(getPlace_B(1)==0&&boat==5&&rightBankCrossers.contains(fox1)){setPositionToCharacterPlace_B(0);
              fox.setLayoutX(450);
              fox.setLayoutY(275);
              rightBankCrossers.remove(fox1);
             }
             else if(getPlace_B(0)==0&&boat==6&&leftBankCrossers.contains(fox1)){
             fox.setLayoutX(270);
             fox.setLayoutY(275);
             leftBankCrossers.remove(fox1);
             }
             else if(getPlace_B(1)==0&&boat==6&&leftBankCrossers.contains(fox1)){
             fox.setLayoutX(209);
             fox.setLayoutY(275);
             leftBankCrossers.remove(fox1);
             }
             
             
            boatRiders.add((ICrosser) fox1);
         }
         else if((boatRiders.contains(fox1)||boatRiders.contains(fox1))&&boat==5){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(fox1)==i){
                boatRiders.remove(i);
                rightBankCrossers.add(fox1);
                }
                }
                removePositionToCharacterPlace_B(0);
                fox.setLayoutX(746);
                fox.setLayoutY(242);
                
         }
         else if((boatRiders.contains(fox1))&&boat==6){
                for (int i=0;i<boatRiders.size();i++){
                if (boatRiders.indexOf(fox1)==i){
                boatRiders.remove(i);
                leftBankCrossers.add(fox1);
                }
                }
                removePositionToCharacterPlace_B(0);
                fox.setLayoutX(54);
                fox.setLayoutY(242);        
         }
        if (leftBankCrossers.size()==4)System.out.println("youu Won ;)"); }    
    
        @FXML
    private void letsGo(ActionEvent event) throws IOException {
        int coor=270;
        if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==5){
        for (int i=0;i<boatRiders.size();i++,coor-=70){
        int m= boatRiders.get(i).getMode();
        if(m==sheep1.getMode()){
         sheep.setLayoutX(coor);
         sheep.setLayoutY(255);  
        }
        else if(m==goat1.getMode()){
         goat.setLayoutX(coor);
         goat.setLayoutY(255);  
        }if(m==fox1.getMode()){
         fox.setLayoutX(coor);
         fox.setLayoutY(255);  }
        else if(m==lion1.getMode()){
         sheep.setLayoutX(coor);
         sheep.setLayoutY(255);  }
        else if(m==lion1.getMode()){
         lion.setLayoutX(coor);
         lion.setLayoutY(255);   }
        else if(m==plant1.getMode()){
         plant.setLayoutX(coor);
         plant.setLayoutY(255);  }
        else if(m==farmer1.getMode()){
         farmer.setLayoutX(coor);
         farmer.setLayoutY(255);  }
         
       }            
            k.setLayoutX(209);k.setLayoutY(270);
            boat=6;
        }
        else if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==6){
        int coor2=509;
        for (int i=0;i<boatRiders.size();i++,coor2-=70){
        int m= boatRiders.get(i).getMode();
        if(m==sheep1.getMode()){
         sheep.setLayoutX(coor2);
         sheep.setLayoutY(255);  
        }
        else if(m==goat1.getMode()){
         goat.setLayoutX(coor2);
         goat.setLayoutY(255);  
        }if(m==fox1.getMode()){
         fox.setLayoutX(coor2);
         fox.setLayoutY(255);  }
        else if(m==lion1.getMode()){
         sheep.setLayoutX(coor2);
         sheep.setLayoutY(255);  }
        else if(m==lion1.getMode()){
         lion.setLayoutX(coor2);
         lion.setLayoutY(255);   }
        else if(m==plant1.getMode()){
         plant.setLayoutX(coor2);
         plant.setLayoutY(255);  }
        else if(m==farmer1.getMode()){
         farmer.setLayoutX(coor2);
         farmer.setLayoutY(255);  }
        }
            k.setLayoutX(449);k.setLayoutY(269);
            boat=5;
        }     
    }
     
   
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) { 
    
    setPositionPlace();
   
    getInitialCrossers();
    
    
    
    
}
    public void setPositionToCharacterPlace_B(int mode){
    if(mode==sheep1.getMode()){
        place_B.add(place_B.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        place_B.add(place_B.indexOf(0),1);
        }if(mode==fox1.getMode()){
        place_B.add(place_B.indexOf(0),1);
        }
        else if(mode==lion1.getMode()){
        place_B.add(place_B.indexOf(0),1);
        }
        else if(mode==farmer1.getMode()){
        place_B.add(place_B.indexOf(0),1);
        }
        else if(mode==plant1.getMode()){
        place_B.add(place_B.indexOf(0),1);
        }
    }
    public void removePositionToCharacterPlace_B(int mode){
    if(mode==sheep1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }
        else if(mode==goat1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }if(mode==fox1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }
        else if(mode==lion1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }
        else if(mode==farmer1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }
        else if(mode==plant1.getMode()){
        place_B.add(place_B.indexOf(1),0);
        }
    }
    
    public void setPositionToCharacterPlace_AandD(int mode){
        //setPositionPlace();System.out.println(place_A.indexOf(0)+"<--");
        if(mode==sheep1.getMode()){
        sheep1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);//System.out.println(getPlace_A(0));
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        goat1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }if(mode==fox1.getMode()){
        fox1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==lion1.getMode()){
        lion1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==farmer1.getMode()){
        farmer1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==plant1.getMode()){
        plant1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
    }
    
    public boolean isValidJumpOnBoat(){
    if(getPlace_B(0)==1&&getPlace_B(1)==1)
        return false;
    return true;
        }
    
    @Override
    public boolean isValid(List<ICrosser> rightBankCrossers, List<ICrosser> leftBankCrossers, List<ICrosser> boatRiders) {
        for (int i = 0; i <rightBankCrossers.size(); i++){
             for (int j = 0; i <rightBankCrossers.size(); i++){
         if(rightBankCrossers.get(i).getEatingRank()==rightBankCrossers.get(j).getEatingRank()-1||rightBankCrossers.get(j).getEatingRank()==rightBankCrossers.get(i).getEatingRank()-1)
         return false;
             }}
         for (int i = 0; i <leftBankCrossers.size(); i++){
             for (int j = 0; i <leftBankCrossers.size(); i++){
         if(leftBankCrossers.get(i).getEatingRank()==leftBankCrossers.get(j).getEatingRank()-1||leftBankCrossers.get(j).getEatingRank()==leftBankCrossers.get(i).getEatingRank()-1)
         return false;
             }}
            int size=boatRiders.size();
                for (int i = 0; i < size; i++) {
            if (boatRiders.get(i).equals(farmer1))return true;
        }
                return false;
            }
        
 
        
    
    
 
    

    @Override
    public List<ICrosser> getInitialCrossers() {
      
        rightBankCrossers.add((ICrosser) sheep1);
        rightBankCrossers.add((ICrosser) fox1);
        rightBankCrossers.add(plant1);
        rightBankCrossers.add((ICrosser) farmer1);
               return rightBankCrossers;
    }

    @Override
    public String[] getInstructions() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
