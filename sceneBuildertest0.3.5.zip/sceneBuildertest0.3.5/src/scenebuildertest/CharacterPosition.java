/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import java.util.LinkedList;

/**
 *
 * @author VEGA
 */
abstract public class CharacterPosition {
    LinkedList<Integer> place_A=new LinkedList();
    LinkedList<Integer> place_B=new LinkedList();
    LinkedList<Integer> place_C=new LinkedList();
    LinkedList<Integer> place_D=new LinkedList();

    public int getPlace_A(int index) {
        return place_A.get(index);
    }

    public void setPlace_A(LinkedList<Integer> place_A) {
        this.place_A = place_A;
    }

    public int getPlace_B(int index) {
        return place_B.get(index);
    }

    public void setPlace_B(int index ,int value) {
        this.place_B.add(index, value);
    }

    public int getPlace_C(int index) {
        return place_C.get(index);
    }

    public void setPlace_C(LinkedList<Integer> place_C) {
        this.place_C = place_C;
    }

    public int getPlace_D(int index) {
        return place_D.get(index);
    }

    public void setPlace_D(LinkedList<Integer> place_D) {
        this.place_D = place_D;
    }
    
    public void setPositionPlace() {
        this.place_A.add(0);
           this.place_A.add(0);
              this.place_A.add(0);
                 this.place_A.add(0);
                    this.place_A.add(0);
                    
        this.place_B.add(0);
            this.place_B.add(0);
            
        this.place_C.add(0);
            this.place_C.add(0);
            
        this.place_D.add(0);
           this.place_D.add(0);
              this.place_D.add(0);
                 this.place_D.add(0);
                    this.place_D.add(0);
    }
    
    
    
}
