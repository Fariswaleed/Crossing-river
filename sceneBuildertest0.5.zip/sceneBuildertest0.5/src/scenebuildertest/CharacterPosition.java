/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import java.util.LinkedList;
import java.util.List;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

/**
 *
 * @author VEGA
 */
abstract public class CharacterPosition {
    LinkedList<Integer> place_A=new LinkedList();
    LinkedList<Integer> place_B=new LinkedList();
    LinkedList<Integer> place_C=new LinkedList();
    LinkedList<Integer> place_D=new LinkedList();
public void setOnbank(ImageView character,int position,int boat){
    System.out.println(position+"<--");
    if (boat==5){
    if (position==0){
    character.setLayoutX(530);
    character.setLayoutY(212);
    }
    else if(position==1){
    character.setLayoutX(584);
    character.setLayoutY(212);
    }
    else if(position==2){
    character.setLayoutX(638);
    character.setLayoutY(214);
    }
    else if(position==3){
    character.setLayoutX(692);
    character.setLayoutY(226);
    }
    else if(position==4){
    character.setLayoutX(746);
    character.setLayoutY(242);
    }
    }
    else {
    if (position==0){
    character.setLayoutX(270);
    character.setLayoutY(242);
    }
    else if(position==1){
    character.setLayoutX(216);
    character.setLayoutY(242);
    }
    else if(position==2){
    character.setLayoutX(162);
    character.setLayoutY(242);
    }
    else if(position==3){
    character.setLayoutX(108);
    character.setLayoutY(242);
    }
    else if(position==4){
    character.setLayoutX(54);
    character.setLayoutY(242);
    }
    }
    }
    public void setOnbankHBox(ImageView character,List<ICrosser> rightBankCrossers,List<ICrosser> boatRiders,List<ICrosser> leftBankCrossers,ICrosser character1,int boat,HBox rightHbox,HBox leftHbox,HBox boatHbox, int win){
    if (isValidJumpOnBoat(boatRiders)&&!(boatRiders.contains(character1))) {
             
             if((boatRiders.size()==0)&&(boat==5)&&rightBankCrossers.contains(character1)){
              rightBankCrossers.remove(character1);
              boatRiders.add((ICrosser) character1);
              rightHbox.getChildren().remove(character);
              boatHbox.getChildren().add(character);System.out.println("noo1");
             }
             else if(boatRiders.size()==1&&boat==5&&rightBankCrossers.contains(character1)){
              rightBankCrossers.remove(character1);
              boatRiders.add((ICrosser) character1);
              rightHbox.getChildren().remove(character);
              boatHbox.getChildren().add(character);System.out.println("noo2");
             }
             else if(boatRiders.size()==0&&boat==6&&leftBankCrossers.contains(character1)){
             leftBankCrossers.remove(character1);
             boatRiders.add((ICrosser) character1);
             leftHbox.getChildren().remove(character);
             boatHbox.getChildren().add(character);System.out.println("noo3");
             }
             else if(boatRiders.size()==1&&boat==6&&leftBankCrossers.contains(character1)){
             leftBankCrossers.remove(character1);
             boatRiders.add((ICrosser) character1);
             leftHbox.getChildren().remove(character);
             boatHbox.getChildren().add(character);System.out.println("noo4");
             }
             else System.out.println("invalid move");
         }
         else if((boatRiders.contains(character1))&&boat==5){
                boatRiders.remove(character1);
                rightBankCrossers.add(character1);
                rightHbox.getChildren().add(character);System.out.println("noo");
         }
         else if((boatRiders.contains(character1))&&boat==6){
                boatRiders.remove(character1);
                leftBankCrossers.add(character1);
                leftHbox.getChildren().add(character);System.out.println("yess");
        }
         else System.out.println("invalid move");
        if (leftBankCrossers.size()==win)System.out.println("youu Won ;)");
    }
    public boolean isValidJumpOnBoat(List<ICrosser> boatRiders){
    if(boatRiders.size()==2)
        return false;
    return true;
        }
    public int getPlace_A(int index) {
        return place_A.get(index);
    }

    public void setPlace_A(LinkedList<Integer> place_A) {
        this.place_A = place_A;
    }

    public int getPlace_B(int index) {
        return place_B.get(index);
    }

    public void setPlace_B(int index ,int value) {
        this.place_B.add(index, value);
    }

    public int getPlace_C(int index) {
        return place_C.get(index);
    }

    public void setPlace_C(LinkedList<Integer> place_C) {
        this.place_C = place_C;
    }

    public int getPlace_D(int index) {
        return place_D.get(index);
    }

    public void setPlace_D(LinkedList<Integer> place_D) {
        this.place_D = place_D;
    }
    
    public void setPositionPlace() {
        this.place_A.add(0);
           this.place_A.add(0);
              this.place_A.add(0);
                 this.place_A.add(0);
                    this.place_A.add(0);
                    
        this.place_B.add(0);
            this.place_B.add(0);
            
        this.place_C.add(0);
            this.place_C.add(0);
            
        this.place_D.add(0);
           this.place_D.add(0);
              this.place_D.add(0);
                 this.place_D.add(0);
                    this.place_D.add(0);
    }
    
    
    
}
