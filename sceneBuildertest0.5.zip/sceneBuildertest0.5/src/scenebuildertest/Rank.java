package scenebuildertest;

public class Rank {
	boolean on;
	public void switchOn() {
		System.out.println("Rank: switch on");
                on=true;
	}
	
	public void switchOff() {
            System.out.println("Rank: switch off");
               on=false;

	}}
