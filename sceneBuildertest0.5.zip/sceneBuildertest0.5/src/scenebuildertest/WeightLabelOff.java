package scenebuildertest;

public class WeightLabelOff implements Command{
	private WeightLabel weightLabel;
	public WeightLabelOff(WeightLabel weightLabel) {
		this.weightLabel = weightLabel;
	}
	@Override
	public void execute() {
		weightLabel.switchOff();
	}
//	@Override
//	public void undo() {
//		weightLabel.switchOn();
//		
//	}

}
