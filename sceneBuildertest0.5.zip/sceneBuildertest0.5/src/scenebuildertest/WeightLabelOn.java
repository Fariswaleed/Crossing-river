package scenebuildertest;

public class WeightLabelOn implements Command{
	private WeightLabel weightlabel;
	public WeightLabelOn(WeightLabel weightlabel) {
		this.weightlabel = weightlabel;
	}
	@Override
	public void execute() {
		weightlabel.switchOn();
	}
//	@Override
//	public void undo() {
//		light.switchOff();
//		
//	}

}
