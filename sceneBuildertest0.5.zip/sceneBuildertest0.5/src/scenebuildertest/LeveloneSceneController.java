/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import com.sun.javafx.geom.Curve;
import com.sun.javafx.geom.RectBounds;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.PathTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.NodeOrientation;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Path;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.QuadCurve;


/**
 * FXML Controller class
 *
 * @author Muhammmad Akram
 */
public class LeveloneSceneController extends CharacterPosition implements Initializable,ICrossingStrategy  {

    /**
     * Initializes the controller class.
     */
    Lion lion1=new Lion(5);
    Fox fox1=new Fox(0);
    Sheep sheep1= new Sheep(1);
    Goat goat1= new Goat(6);
    Farmer farmer1= new Farmer(3);
    Plant plant1=new Plant(2);
    List<ICrosser> rightBankCrossers = new ArrayList<ICrosser>();
    List<ICrosser> leftBankCrossers =new ArrayList<ICrosser>();
    List<ICrosser> boatRiders = new ArrayList<ICrosser>();
    int moves=0;
    int boat=5;
    
    
    @FXML
    private Button raftMotion;
    int x=0;
    int currentPosition=0;
    @FXML
    private ImageView k;
    @FXML
    private ImageView sheep;
    @FXML
    private ImageView farmer;
    @FXML
    private ImageView plant;
    @FXML
    private ImageView fox;
    @FXML
    private ImageView lion;
    @FXML
    private ImageView goat;
    @FXML
    private HBox leftHbox;

    @FXML
    private HBox rightHbox;

    @FXML
    private HBox boatHbox;
    @FXML
    private Label movesCounter;
    
    
//    @FXML
//    private void bagarb(ActionEvent event) throws IOException {
//        path.getElements().add(moveTO);
//        path.getElements().add(arcTo);
//        
//    }
    
    @FXML
    private void reload(ActionEvent event) throws IOException {
        System.out.println("Reload Action");
        
    }
        @FXML
    private void Back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Levels.fxml"));
        
        Scene scene = new Scene(root);
        
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(scene);
        window.show();
        
    }
        @FXML
    private void hint(ActionEvent event) throws IOException {
        System.out.println("hint Action");
        
    }
     @FXML
    private void moveSheepToRaft(MouseEvent event) throws IOException { System.out.println("w ba3deen");
    setOnbankHBox(sheep, rightBankCrossers, boatRiders, leftBankCrossers, sheep1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
     System.out.println("yalaa");
    
    }
    
    
    @FXML
     private void moveFarmerToRaft(MouseEvent event) throws IOException {
     setOnbankHBox(farmer, rightBankCrossers, boatRiders, leftBankCrossers, farmer1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
    
         }
     
        @FXML
        private void moveLionToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(lion, rightBankCrossers, boatRiders, leftBankCrossers, lion1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
    
        }

         
               @FXML
         private void moveGoatToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(goat, rightBankCrossers, boatRiders, leftBankCrossers, goat1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
    }
         @FXML
             private void moveplantToRaft(MouseEvent event) throws IOException {
            setOnbankHBox(plant, rightBankCrossers, boatRiders, leftBankCrossers, plant1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
    }
               
            @FXML   
        private void moveFoxToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(fox, rightBankCrossers, boatRiders, leftBankCrossers, fox1, boat, rightHbox, leftHbox, boatHbox,4,null,null,null,null);
     }    
    
        @FXML
    private void letsGo(ActionEvent event) throws IOException {
       if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==5){
            boatHbox.setLayoutX(270);
            //boatHbox.setLayoutY(400);
            k.setLayoutX(270);
            //k.setLayoutY(410);
            boat=6;
                        moves++;
                        movesCounter.setText(String.valueOf(moves));
            
        }
        else if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==6){
            boatHbox.setLayoutX(600);
            //boatHbox.setLayoutY(400);
            k.setLayoutX(600);
            //k.setLayoutY(410);
            boat=5;
            moves++;
            movesCounter.setText(String.valueOf(moves));
             
    }
    }
     
   
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       movesCounter.setText(String.valueOf(moves));
     rightHbox.getChildren().add(farmer);
//        rightHbox.getChildren().add(lion);
        rightHbox.getChildren().add(sheep);
//        rightHbox.getChildren().add(goat);
        rightHbox.getChildren().add(fox);
        rightHbox.getChildren().add(plant);
    setPositionPlace();
   
    getInitialCrossers();
    
    
    
    
}
    
    
    public void setPositionToCharacterPlace_B(int mode){
    if(mode==sheep1.getMode()){sheep1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }
        else if(mode==goat1.getMode()){goat1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }if(mode==fox1.getMode()){fox1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }
        else if(mode==lion1.getMode()){lion1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }
        else if(mode==farmer1.getMode()){farmer1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }
        else if(mode==plant1.getMode()){plant1.setIndexOnBoat(place_B.indexOf(0));
        place_B.set(place_B.indexOf(0),1);
        }
    }
    public void removePositionToCharacterPlace_B(int mode){
    if(mode==sheep1.getMode()){
        place_B.set(sheep1.getIndexOnBoat(),0);sheep1.setIndexOnBoat(-1);
        }
        else if(mode==goat1.getMode()){
        place_B.set(goat1.getIndexOnBoat(),0);goat1.setIndexOnBoat(-1);
        }else if(mode==fox1.getMode()){
        place_B.set(fox1.getIndexOnBoat(),0);fox1.setIndexOnBoat(-1);
        }
        else if(mode==lion1.getMode()){
        place_B.set(lion1.getIndexOnBoat(),0);lion1.setIndexOnBoat(-1);
        }
        else if(mode==farmer1.getMode()){
        place_B.set(farmer1.getIndexOnBoat(),0);farmer1.setIndexOnBoat(-1);
        }
        else if(mode==plant1.getMode()){
        place_B.set(plant1.getIndexOnBoat(),0);plant1.setIndexOnBoat(-1);
        }
    }
    
    public void setPositionToCharacterPlace_A(int mode){
        //setPositionPlace();System.out.println(place_D.indexOf(0)+"<--");
        if(mode==sheep1.getMode()){
        sheep1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);//System.out.println(getPlace_A(0));
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        goat1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }if(mode==fox1.getMode()){
        fox1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==lion1.getMode()){
        lion1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==farmer1.getMode()){
        farmer1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==plant1.getMode()){
        plant1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
    }
        public void removePositionToCharacterPlace_A(int mode){
        //setPositionPlace();System.out.println(place_A.indexOf(0)+"<--");
        if(mode==sheep1.getMode()){
        sheep1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);//System.out.println(getPlace_A(0));
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        goat1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }if(mode==fox1.getMode()){
        fox1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==lion1.getMode()){
        lion1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==farmer1.getMode()){
        farmer1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==plant1.getMode()){
        plant1.setPosition(place_A.indexOf(0));
        place_A.add(place_A.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
    }
         public void setPositionToCharacterPlace_D(int mode){
        //setPositionPlace();System.out.println(place_A.indexOf(0)+"<--");
        if(mode==sheep1.getMode()){
        sheep1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        goat1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }if(mode==fox1.getMode()){
        fox1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==lion1.getMode()){
        lion1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==farmer1.getMode()){
        farmer1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
        else if(mode==plant1.getMode()){
        plant1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(0),1);
        //place_D.add(place_D.indexOf(0),1);//System.out.println(getPlace_A(0));
        }
    }
        public void removePositionToCharacterPlace_D(int mode){
        //setPositionPlace();System.out.println(place_D.indexOf(0)+"<--");
        if(mode==sheep1.getMode()){
        sheep1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==goat1.getMode()){
        goat1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }if(mode==fox1.getMode()){
        fox1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==lion1.getMode()){
        lion1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==farmer1.getMode()){
        farmer1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
        else if(mode==plant1.getMode()){
        plant1.setPosition(place_D.indexOf(0));
        place_D.add(place_D.indexOf(1),0);
        //place_D.add(place_D.indexOf(1),0);//System.out.println(getPlace_A(0));
        }
    }
    public boolean isValidJumpOnBoat(){
    if(getPlace_B(0)==1&&getPlace_B(1)==1)
        return false;
    return true;
        }
    
    @Override
    public boolean isValid(List<ICrosser> rightBankCrossers, List<ICrosser> leftBankCrossers, List<ICrosser> boatRiders) {
        for (int i = 0; i <rightBankCrossers.size(); i++){
             for (int j = 0; i <rightBankCrossers.size(); i++){
         if(rightBankCrossers.get(i).getEatingRank()==rightBankCrossers.get(j).getEatingRank()-1||rightBankCrossers.get(j).getEatingRank()==rightBankCrossers.get(i).getEatingRank()-1)
         return false;
             }}
         for (int i = 0; i <leftBankCrossers.size(); i++){
             for (int j = 0; i <leftBankCrossers.size(); i++){
         if(leftBankCrossers.get(i).getEatingRank()==leftBankCrossers.get(j).getEatingRank()-1||leftBankCrossers.get(j).getEatingRank()==leftBankCrossers.get(i).getEatingRank()-1)
         return false;
             }}
            int size=boatRiders.size();
                for (int i = 0; i < size; i++) {
            if (boatRiders.get(i).equals(farmer1))return true;
        }
                return false;
            }
        
 
        
    
    
 
    

    @Override
    public List<ICrosser> getInitialCrossers() {
      
        rightBankCrossers.add((ICrosser) sheep1);
        rightBankCrossers.add((ICrosser) fox1);
        rightBankCrossers.add(plant1);
        rightBankCrossers.add((ICrosser) farmer1);
               return rightBankCrossers;
    }

    @Override
    public String[] getInstructions() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
