/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

import java.awt.image.BufferedImage;

/**
 *
 * @author Muhammmad Akram
 */
public class Fox extends Carnivorous  implements ICrosser 
{

    private int mode;
    private int indexOnBoat=-1;
        

    public int getIndexOnBoat() {
        return indexOnBoat;
    }

    public void setIndexOnBoat(int indexOnBoat) {
        this.indexOnBoat = indexOnBoat;
    }
    
    public Fox(int mode) {
        this.mode=mode;
    }
    @Override
    public boolean canSail() {
       return false;
    }

    @Override
    public double getWeight() {
        return super.weight;
    }

    @Override
    public int getEatingRank() {
          return super.eatingRank;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ICrosser makeCopy() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setLabelToBeShown(String label) {
        super.weight=Double.parseDouble(label);
        
        }

    @Override
    public String getLabelToBeShown() {
        String kg=new String(" kg");
    return String.valueOf(super.weight)+kg;
    }

    @Override
    public int getMode() {
        return mode;}
    
}
