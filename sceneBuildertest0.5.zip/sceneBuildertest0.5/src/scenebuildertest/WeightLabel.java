package scenebuildertest;

public class WeightLabel {
    boolean on;
	public void switchOn() {
		System.out.println("Weight: switch on");
                on=true;
	}
	
	public void switchOff() {
               on=false;
System.out.println("Weight: switch off");
	}
}
