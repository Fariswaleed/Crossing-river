package scenebuildertest;


public class RankOn implements Command{
	private Rank rank;
	public RankOn(Rank rank) {
		this.rank = rank;
	}
	public void execute() {
		rank.switchOn();
	}
//	public void undo() {
//		tv.turnOff();
//	}

}
