package scenebuildertest;


public class RemoteControl {
	private Command[] onCommands;
	private Command[] offCommands;
	//private Command undoCommand;
	
	public RemoteControl() {
		onCommands = new Command[2];
		offCommands = new Command[2];
		
	}
	
	
	public void level1(int index, Command onCommand,Command offCommand) {
		this.onCommands[index] = onCommand;
                this.offCommands[index+1] = offCommand;
	}
	
	public void level2(int index, Command offCommand,Command onCommand) {
		this.offCommands[index] = offCommand;
                this.onCommands[index+1] = onCommand;
	}
	
	public void pushlevel1(int index) {
            System.out.println("LEVEL1");
		onCommands[index].execute();
                offCommands[index+1].execute();
		//undoCommand = onCommands[index];
	}
	public void pushlevel2(int index) {
            System.out.println("LEVEL2");
		onCommands[index+1].execute();
                offCommands[index].execute();
                
		//undoCommand = offCommands[index];
	}
	
//	public void undo() {
//		System.out.println("---Undo----");
//		undoCommand.undo();
//	}
}
