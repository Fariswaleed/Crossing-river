package scenebuildertest;


public class RankOff implements Command{
	private Rank rank;
	public RankOff(Rank rank) {
		this.rank = rank;
	}
	
	public void execute() {
		rank.switchOff();
	}
	
//	public void undo() {
//		tv.turnOn();
//	}
//	

}
