package scenebuildertest;



public class Main {

	public static void main(String[] args) {
		RemoteControl remoteControl = new RemoteControl();
                Rank rank1=new Rank();
		RankOn level1On=new RankOn(rank1);
                RankOff level1Off=new RankOff(rank1);
                
		WeightLabel weightlabel = new WeightLabel();
		WeightLabelOn level2On = new WeightLabelOn(weightlabel);
		WeightLabelOff level2Off = new WeightLabelOff(weightlabel);
                //rankon
		remoteControl.level1(0, level1On,level2Off);
                //weighton
		remoteControl.level2(0,level1Off ,level2On);
               
		remoteControl.pushlevel1(0);
		remoteControl.pushlevel2(0);
		//remoteControl.undo();
		
		Rank tv = new Rank();
		RankOn tvOnCommand = new RankOn(tv);
		RankOff tvOffCommand = new RankOff(tv);
        }

}
