package scenebuildertest;

import com.sun.javafx.geom.Curve;
import com.sun.javafx.geom.RectBounds;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.PathTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.NodeOrientation;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Path;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.QuadCurve;


/**
 * FXML Controller class
 *
 * @author Muhammmad Akram
 */
public class LevelTwoController extends CharacterPosition implements Initializable,ICrossingStrategy  {

    /**
     * Initializes the controller class.
     */
    Goat goat1= new Goat(6);
    Farmer farmer1= new Farmer(1);
    Farmer farmer2= new Farmer(2);
    Farmer farmer3= new Farmer(3);
    Farmer farmer4= new Farmer(4);
    List<ICrosser> rightBankCrossers = new ArrayList<ICrosser>();
    List<ICrosser> leftBankCrossers =new ArrayList<ICrosser>();
    List<ICrosser> boatRiders = new ArrayList<ICrosser>();
    int moves=0;
    int boat=5;
    
    @FXML
    private Button raftMotion;
    int x=0;
    int currentPosition=0;
    @FXML
    private ImageView k;
    @FXML
    private ImageView farmerA;
    @FXML
    private ImageView farmerB;
    @FXML
    private ImageView farmerC;
    @FXML
    private ImageView farmerD;
    @FXML
    private ImageView goatA;

    @FXML
    private HBox leftHbox;

    @FXML
    private HBox rightHbox;

    @FXML
    private HBox boatHbox;
    @FXML
    private Label farmer90;

    @FXML
    private Label farmer80;

    @FXML
    private Label farmer60;

    @FXML
    private Label farmer40;

    @FXML
    private Label goat20;
    @FXML
    private HBox leftLabel;
    @FXML
    private HBox rightLabel;
    @FXML
    private HBox onBoatLabel;
    @FXML
    private VBox boatVBox;

    @FXML
    private void reload(ActionEvent event) throws IOException {
        System.out.println("Reload Action"); 
    }
        @FXML
    private void Back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Levels.fxml"));
        
        Scene scene = new Scene(root);
        
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(scene);
        
        window.show();
        
    }
        @FXML
        private void hint(ActionEvent event) throws IOException {
        System.out.println("hint Action");
        }
        @FXML
        private void moveGoatToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(goatA, rightBankCrossers, boatRiders, leftBankCrossers, goat1, boat, rightHbox, leftHbox, boatHbox,5,leftLabel,rightLabel,onBoatLabel,goat20);
        }
        @FXML
        private void moveFarmerAToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(farmerA, rightBankCrossers, boatRiders, leftBankCrossers, farmer1, boat, rightHbox, leftHbox, boatHbox,5,leftLabel,rightLabel,onBoatLabel,farmer90);
         }
        @FXML
        private void moveFarmerBToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(farmerB, rightBankCrossers, boatRiders, leftBankCrossers, farmer2, boat, rightHbox, leftHbox, boatHbox,5,leftLabel,rightLabel,onBoatLabel,farmer80);
         } 
        @FXML
        private void moveFarmerCToRaft(MouseEvent event) throws IOException {
        setOnbankHBox(farmerC, rightBankCrossers, boatRiders, leftBankCrossers, farmer3, boat, rightHbox, leftHbox, boatHbox,5,leftLabel,rightLabel,onBoatLabel,farmer60);
         } 
            
       @FXML
       private void moveFarmerDToRaft(MouseEvent event) throws IOException {
       setOnbankHBox(farmerD, rightBankCrossers, boatRiders, leftBankCrossers, farmer4, boat, rightHbox, leftHbox, boatHbox,5,leftLabel,rightLabel,onBoatLabel,farmer40);
         } 
        @FXML
    private void letsGo(ActionEvent event) throws IOException {
        if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==5){
           boatVBox.setLayoutX(270);
            //boatHbox.setLayoutY(400);
            k.setLayoutX(270);
            //k.setLayoutY(410);
            boat=6;
        }
        else if(isValid(rightBankCrossers, leftBankCrossers, boatRiders)&&boat==6){
            boatVBox.setLayoutX(600);
            //boatHbox.setLayoutY(400);
            k.setLayoutX(600);
            //k.setLayoutY(410);
            boat=5;
             
    }
        else {}}
    
    public void setOnbank(ImageView character,List<ICrosser> Crossers,int boat){
    if (boat==5){
    if (Crossers.size()==1){
    character.setLayoutX(530);
    character.setLayoutY(212);
    }
    else if(Crossers.size()==2){
    character.setLayoutX(584);
    character.setLayoutY(212);
    }
    else if(Crossers.size()==3){
    character.setLayoutX(638);
    character.setLayoutY(214);
    }
    else if(Crossers.size()==4){
    character.setLayoutX(692);
    character.setLayoutY(226);
    }
    else if(Crossers.size()==5){
    character.setLayoutX(746);
    character.setLayoutY(242);
    }
    }
    else {
    if (Crossers.size()==1){
    character.setLayoutX(270);
    character.setLayoutY(242);
    }
    else if(Crossers.size()==2){
    character.setLayoutX(216);
    character.setLayoutY(242);
    }
    else if(Crossers.size()==3){
    character.setLayoutX(162);
    character.setLayoutY(242);
    }
    else if(Crossers.size()==4){
    character.setLayoutX(108);
    character.setLayoutY(242);
    }
    else if(Crossers.size()==5){
    character.setLayoutX(54);
    character.setLayoutY(242);
    }
    }
    }
  public boolean isValidJumpOnBoat(){
    if(boatRiders.size()==2)
        return false;
    return true;
        }

   
    @Override
    public boolean isValid(List<ICrosser> rightBankCrossers, List<ICrosser> leftBankCrossers, List<ICrosser> boatRiders) {
        if (boatRiders.size()==1&&boatRiders.get(0).canSail()){
        
        }
        else if(boatRiders.get(0).getWeight()+boatRiders.get(1).getWeight()>100){
        return false;
             }
                for (int i = 0; i <boatRiders.size(); i++) {
            if (boatRiders.get(i).canSail())
                return true;
        }
                return false;
            }
        
 
        
    
    
 
    

    @Override
    public List<ICrosser> getInitialCrossers() {
      
        rightBankCrossers.add((ICrosser) farmer1);
        rightBankCrossers.add((ICrosser) farmer2);
        rightBankCrossers.add(goat1);
        rightBankCrossers.add((ICrosser) farmer3);
        rightBankCrossers.add((ICrosser) farmer4);
               return rightBankCrossers;
    }

    @Override
    public String[] getInstructions() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        rightHbox.getChildren().add(farmerA);rightLabel.getChildren().add(farmer90);
        rightHbox.getChildren().add(farmerB);rightLabel.getChildren().add(farmer80);
        rightHbox.getChildren().add(farmerC);rightLabel.getChildren().add(farmer60);
        rightHbox.getChildren().add(farmerD);rightLabel.getChildren().add(farmer40);
        rightHbox.getChildren().add(goatA);rightLabel.getChildren().add(goat20);
    farmer1.setLabelToBeShown("90");
    farmer2.setLabelToBeShown("80");
    farmer3.setLabelToBeShown("60");
    farmer4.setLabelToBeShown("40");
    goat1.setLabelToBeShown("20");
    farmer90.setText(farmer1.getLabelToBeShown());farmer80.setText(farmer2.getLabelToBeShown());farmer60.setText(farmer3.getLabelToBeShown());farmer40.setText(farmer4.getLabelToBeShown());goat20.setText(goat1.getLabelToBeShown());
    setPositionPlace();
   
    getInitialCrossers();
    

    }
    
}
  

