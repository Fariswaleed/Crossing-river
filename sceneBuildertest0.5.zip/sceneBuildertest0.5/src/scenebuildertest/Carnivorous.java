/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuildertest;

/**
 *
 * @author Muhammmad Akram
 */
public class Carnivorous {
    protected final int eatingRank=3;
    protected double weight=50;
    protected int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
    
}
